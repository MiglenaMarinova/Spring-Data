package com.example.jsonexercise.util;

public interface ValidationUtil {
    <E> boolean isValid(E entity);
}
