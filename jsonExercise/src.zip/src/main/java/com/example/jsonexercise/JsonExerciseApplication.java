package com.example.jsonexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonExerciseApplication.class, args);
    }

}
