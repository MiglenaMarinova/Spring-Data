package com.example.jsonexercise.constant;

public class GlobalConstant {

    public static final String RESOURCES_FILE_PATH = "src/main/resources/files/";
}
