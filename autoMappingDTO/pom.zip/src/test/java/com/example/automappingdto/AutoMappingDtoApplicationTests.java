package com.example.automappingdto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoMappingDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
