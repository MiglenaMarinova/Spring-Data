package com.example.xmlexercise.util;

public interface ValidationUtil {
    <T> boolean isValid(T entity);
}
