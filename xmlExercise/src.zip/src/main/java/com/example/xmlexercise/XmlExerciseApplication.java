package com.example.xmlexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlExerciseApplication.class, args);
	}

}
